Nifty Intraday Advanced Backend
===============================

Files:
- main.py   (Flask app with /signal and /option_reco endpoints)
- requirements.txt

How to deploy to Render:
1. Create a public GitHub repo and push these files.
2. On Render, create a new Web Service and connect the repo.
3. Set the build command to: pip install -r requirements.txt
4. Set the start command to: python main.py
5. Deploy — the service will provide a public URL like https://your-app.onrender.com
6. Use /signal and /option_reco endpoints from the Flutter app.

Endpoints:
- GET /signal  -> returns signal, probabilities, last_price, rsi, short_ma, long_ma
- GET /option_reco?days_to_expiry=2&step=50 -> returns option recommendation and estimated premium