Nifty Intraday Advanced Flutter App
==================================

This Flutter project is wired to your backend at:
https://nifty-intraday-app-1.onrender.com

How to build on Codemagic:
1. Go to https://codemagic.io and sign in.
2. Create a new app and upload this ZIP.
3. Set Flutter channel to stable, build Android APK (release).
4. Start build and download the APK.

The app polls /signal and /option_reco endpoints.