
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:intl/intl.dart';

const String BACKEND_BASE = "https://nifty-intraday-app-1.onrender.com";

void main() { runApp(const NiftyAdvancedApp()); }

class NiftyAdvancedApp extends StatelessWidget { const NiftyAdvancedApp({super.key}); @override Widget build(BuildContext context) { return MaterialApp(title: 'Nifty Intraday Advanced', theme: ThemeData(primarySwatch: Colors.indigo), home: const HomeScreen()); } }

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _HomeScreenState(); }

class _HomeScreenState extends State<HomeScreen> {
  String status = 'Loading...';
  double lastPrice = 0.0;
  double rsi = 0.0;
  Map<String,double> probs = {};
  List<String> alerts = [];
  Map<String,dynamic>? reco;
  Timer? timer;
  final FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

  @override
  void initState() {
    super.initState();
    _initNotifications();
    fetchAll();
    timer = Timer.periodic(const Duration(seconds: 60), (_) => fetchAll());
  }

  @override
  void dispose() { timer?.cancel(); super.dispose(); }

  Future<void> _initNotifications() async { 
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const initSettings = InitializationSettings(android: androidInit);
    await flutterLocalNotificationsPlugin.initialize(initSettings);
  }

  Future<void> _notify(String title, String body) async { 
    const androidDetails = AndroidNotificationDetails('nifty_channel', 'Nifty Alerts', channelDescription: 'Intraday alerts', importance: Importance.max, priority: Priority.high);
    const generalDetails = NotificationDetails(android: androidDetails);
    await flutterLocalNotificationsPlugin.show(0, title, body, generalDetails);
  }

  Future<void> fetchAll() async { 
    await Future.wait([fetchSignal(), fetchRecommendation()]);
  }

  Future<void> fetchSignal() async { 
    try { 
      final url = Uri.parse('$BACKEND_BASE/signal');
      final resp = await http.get(url).timeout(const Duration(seconds: 10));
      if (resp.statusCode == 200) { 
        final data = json.decode(resp.body);
        setState(() { 
          status = data['signal'] ?? 'N/A';
          lastPrice = (data['last_price'] ?? 0) * 1.0;
          rsi = (data['rsi'] ?? 0) * 1.0;
          final p = data['probabilities'] ?? {};
          probs = p.map((k,v) => MapEntry(k.toString(), (v as num).toDouble()));
          final newAlerts = <String>[];
          if (data['signal'] != null) newAlerts.add('Signal: ' + data['signal'].toString());
          if (data['rsi'] != null) newAlerts.add('RSI: ' + data['rsi'].toString());
          for (final a in newAlerts) { if (!alerts.contains(a)) { alerts.insert(0,a); _notify('Nifty Alert', a); } }
        });
      } else { setState(() { status = 'Error ${resp.statusCode}'; }); }
    } catch (e) { setState(() { status = 'Fetch error'; }); }
  }

  Future<void> fetchRecommendation() async { 
    try { 
      final url = Uri.parse('$BACKEND_BASE/option_reco?days_to_expiry=2&step=50');
      final resp = await http.get(url).timeout(const Duration(seconds: 12));
      if (resp.statusCode == 200) { 
        final data = json.decode(resp.body);
        setState(() { reco = data['recommendation']; });
      }
    } catch (e) { /* ignore */ }
  }

  String _nicePrice(double p) => NumberFormat.currency(locale: 'en_IN', symbol: '₹').format(p);

  @override Widget build(BuildContext context) { 
    return Scaffold(
      appBar: AppBar(title: const Text('Nifty Intraday - Advanced')),
      body: RefreshIndicator(
        onRefresh: fetchAll,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Status: $status', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text('Last Price: ' + _nicePrice(lastPrice), style: const TextStyle(fontSize: 18)),
              const SizedBox(height: 6),
              Text('RSI: ' + rsi.toStringAsFixed(2), style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 6),
              if (probs.isNotEmpty) Wrap(spacing:10, children: probs.entries.map((e) => Chip(label: Text('${e.key}: ${e.value}%'))).toList()),
            ]))),
            const SizedBox(height: 12),
            Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Option Recommendation', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (reco != null) ...[
                Text('Side: ' + (reco!['side'] ?? 'N/A')),
                Text('Strike: ' + (reco!['strike']?.toString() ?? 'N/A')),
                Text('Est. Premium: ' + (reco!['estimated_premium'] != null ? _nicePrice((reco!['estimated_premium']*1.0)) : 'N/A')),
              ] else const Text('No recommendation yet. Pull to refresh.'),
            ]))),
            const SizedBox(height: 12),
            Card(child: Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Alerts', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              if (alerts.isEmpty) const Text('No alerts yet. Pull to refresh.'),
              ...alerts.map((a) => ListTile(title: Text(a))).toList(),
            ]))),
            const SizedBox(height: 20),
            ElevatedButton.icon(onPressed: () async { await fetchAll(); }, icon: const Icon(Icons.refresh), label: const Text('Refresh Now')),
            const SizedBox(height: 20),
            Text('Built to work with backend: https://nifty-intraday-app-1.onrender.com', style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
